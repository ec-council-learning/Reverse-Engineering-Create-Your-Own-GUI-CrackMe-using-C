//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnActivateClick(TObject *Sender)
{
  tcpClient->Connect();
  tcpClient->Socket->Write(editSerial->Text.ToInt());

  int response = tcpClient->Socket->ReadInt32();

  String serverStr = IntToStr(response);

  if(serverStr.Compare("1")==0){
	labelStatus->Caption = "REGISTERED";
	Application->MessageBox(L"Correct Key",L"Thank You",MB_OK | MB_ICONASTERISK);
  } else {
	labelStatus->Caption = "UN-REGISTERED";
	Application->MessageBox(L"WRONG Serial",L"Error",MB_OK | MB_ICONERROR);
  }
}
//---------------------------------------------------------------------------
