//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------

bool isDebuggerDetected = false;

void __fastcall TForm1::timerCheckDebuggerTimer(TObject *Sender)
{
  if(IsDebuggerPresent()){
	isDebuggerDetected = true;
	labelStatus->Caption = "Debugger DETECTED";
  } else {
	isDebuggerDetected = false;
	labelStatus->Caption = "Debugger Not Detected";
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnCheckClick(TObject *Sender)
{
  String serialKey = editSerial->Text;

  if(isDebuggerDetected){
	Application->MessageBox(L"Program Will Now Quit",L"Debugger Detected",MB_OK|MB_ICONERROR);
	Application->Terminate();
  }

  if(serialKey.Compare("123456")==0){
	Application->MessageBox(L"Correct Key",L"Thank You",MB_OK|MB_ICONASTERISK);
  } else {
	Application->MessageBox(L"Sorry Wrong Key",L"EROR",MB_OK|MB_ICONERROR);
  }
}
//---------------------------------------------------------------------------

