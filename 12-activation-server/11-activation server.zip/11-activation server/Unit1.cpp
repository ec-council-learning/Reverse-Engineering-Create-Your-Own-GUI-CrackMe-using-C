//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnStartClick(TObject *Sender)
{
  labelStatus->Caption = "Server Started";
  tcpServer->Active = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::tcpServerExecute(TIdContext *AContext)
{
  int numReceived = AContext->Connection->Socket->ReadInt32();

  if(numReceived == 1234){
	labelStatus->Caption = "CORRECT Serial Received";
	AContext->Connection->Socket->Write(1);
  } else {
	labelStatus->Caption = "WRONG Serial Received";
	AContext->Connection->Socket->Write(0);
  }

  AContext->Connection->Disconnect();
}
//---------------------------------------------------------------------------
