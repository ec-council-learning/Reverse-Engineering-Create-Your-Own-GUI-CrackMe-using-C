//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  int daysRemaining = 0;
  SYSTEMTIME lt = {0};
  GetLocalTime(&lt);
  daysRemaining = 28 - lt.wDay;
  if(daysRemaining <= 0) {
	  labelMessage->Caption = "Trial Expired";
  } else {
      labelMessage->Caption = IntToStr(daysRemaining);
  }
}
//---------------------------------------------------------------------------
