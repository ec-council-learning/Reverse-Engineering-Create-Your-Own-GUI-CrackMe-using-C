//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnCheckClick(TObject *Sender)
{
   SYSTEMTIME lt = {0};
   wchar_t* fname = L"0000000000000000";
   wchar_t* genRegStr = L"0000000000000000";
   wchar_t* serialKey = L"0000000000000000";
   fname = editName->Text.SubString(0,4).c_str();

   serialKey = editSerial->Text.SubString(0,12).c_str();
   GetLocalTime(&lt);

   swprintf(genRegStr, L"%s-%d%d%d",fname,lt.wYear,lt.wMonth,lt.wDay);

   if(wcscmp(genRegStr,serialKey)!=0){
	   //swprintf(serialKey,L"Correct should be: %s",genRegStr);
	   //Application->MessageBox(serialKey,L"Answer",MB_OK|MB_ICONASTERISK);
	   Application->MessageBox(L"Wrong Serial Key",L"Error",MB_OK|MB_ICONERROR);
   } else {
	   Application->MessageBox(L"Correct Serial Key",L"Well Done",MB_OK|MB_ICONASTERISK);
   }
}
//---------------------------------------------------------------------------
