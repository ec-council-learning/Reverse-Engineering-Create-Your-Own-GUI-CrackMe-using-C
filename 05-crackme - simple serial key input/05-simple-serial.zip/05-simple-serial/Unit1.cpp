//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnCheckClick(TObject *Sender)
{
   String serialKey = editSerial->Text;
   if(serialKey.Compare("ABC-123456")==0){
	 Application->MessageBox(L"Correct Key",L"Thank you",MB_OK|MB_ICONASTERISK);
   } else {
	 Application->MessageBox(L"Sorry wrong key",L"Error",MB_OK|MB_ICONERROR);
   }

}
//---------------------------------------------------------------------------
